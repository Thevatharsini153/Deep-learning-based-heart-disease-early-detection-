import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Auth } from './components/Auth';
import { PatientSetup } from './components/PatientSetup';
import { Dashboard } from './components/Dashboard';
import { ECGAnalysis } from './components/ECGAnalysis';
import { VoiceAnalysis } from './components/VoiceAnalysis';
import { CombinedAnalysis } from './components/CombinedAnalysis';
import { supabase, type Patient, type ECGAnalysis as ECGAnalysisType, type VoiceAnalysis as VoiceAnalysisType } from './lib/supabase';
import { Heart, Activity, Volume2, BarChart3, LogOut, User } from 'lucide-react';

const AppContent = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'ecg' | 'voice' | 'assessment'>('dashboard');
  const [latestECG, setLatestECG] = useState<ECGAnalysisType | null>(null);
  const [latestVoice, setLatestVoiceAnalysis] = useState<VoiceAnalysisType | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (user) {
      loadPatient();
    } else {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (patient) {
      loadLatestAnalyses();
    }
  }, [patient]);

  const loadPatient = async () => {
    try {
      const { data, error } = await supabase
        .from('patients')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error) throw error;

      setPatient(data);
    } catch (error) {
      console.error('Error loading patient:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadLatestAnalyses = async () => {
    if (!patient) return;

    try {
      const [ecgData, voiceData] = await Promise.all([
        supabase
          .from('ecg_analyses')
          .select('*')
          .eq('patient_id', patient.id)
          .order('analysis_timestamp', { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase
          .from('voice_analyses')
          .select('*')
          .eq('patient_id', patient.id)
          .order('analysis_timestamp', { ascending: false })
          .limit(1)
          .maybeSingle()
      ]);

      if (ecgData.data) setLatestECG(ecgData.data);
      if (voiceData.data) setLatestVoiceAnalysis(voiceData.data);
    } catch (error) {
      console.error('Error loading latest analyses:', error);
    }
  };

  const handleAnalysisComplete = () => {
    loadLatestAnalyses();
    setRefreshKey(prev => prev + 1);
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-red-500 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  if (!patient) {
    return <PatientSetup userId={user.id} onComplete={loadPatient} />;
  }

  const tabs = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: BarChart3 },
    { id: 'ecg' as const, label: 'ECG Analysis', icon: Activity },
    { id: 'voice' as const, label: 'Voice Analysis', icon: Volume2 },
    { id: 'assessment' as const, label: 'Risk Assessment', icon: Heart },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-red-500 to-pink-500 p-2 rounded-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">CardioAI</h1>
                <p className="text-xs text-gray-600">Heart Disease Detection</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-lg">
                <User className="w-4 h-4 text-gray-600" />
                <span className="text-sm font-medium text-gray-800">{patient.full_name}</span>
              </div>
              <button
                onClick={signOut}
                className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
          <div className="flex border-b border-gray-200 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-4 font-medium whitespace-nowrap transition ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          {activeTab === 'dashboard' && <Dashboard key={refreshKey} patientId={patient.id} />}
          {activeTab === 'ecg' && (
            <ECGAnalysis patientId={patient.id} onAnalysisComplete={handleAnalysisComplete} />
          )}
          {activeTab === 'voice' && (
            <VoiceAnalysis patientId={patient.id} onAnalysisComplete={handleAnalysisComplete} />
          )}
          {activeTab === 'assessment' && (
            <CombinedAnalysis
              patientId={patient.id}
              latestECG={latestECG}
              latestVoice={latestVoiceAnalysis}
              onComplete={handleAnalysisComplete}
            />
          )}
        </div>
      </div>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
