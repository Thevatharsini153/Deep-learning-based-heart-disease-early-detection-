import { useState, useRef } from 'react';
import { Upload, Activity, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { analyzeECGImage } from '../lib/mlModels';
import { supabase } from '../lib/supabase';

interface ECGAnalysisProps {
  patientId: string;
  onAnalysisComplete: () => void;
}

export const ECGAnalysis = ({ patientId, onAnalysisComplete }: ECGAnalysisProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setResult(null);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedFile) return;

    setAnalyzing(true);
    try {
      const analysisResult = await analyzeECGImage(selectedFile);

      const imageUrl = preview || '';

      const { error } = await supabase.from('ecg_analyses').insert({
        patient_id: patientId,
        image_url: imageUrl,
        classification_result: analysisResult.classification_result,
        confidence_score: analysisResult.confidence_score,
        detected_conditions: analysisResult.detected_conditions,
        heart_rate: analysisResult.heart_rate,
      });

      if (error) throw error;

      setResult(analysisResult);
      onAnalysisComplete();
    } catch (error: any) {
      console.error('Analysis failed:', error);
      alert('Analysis failed: ' + error.message);
    } finally {
      setAnalyzing(false);
    }
  };

  const getResultColor = (classification: string) => {
    switch (classification) {
      case 'Normal': return 'text-green-600';
      case 'Abnormal': return 'text-yellow-600';
      case 'Critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getResultIcon = (classification: string) => {
    switch (classification) {
      case 'Normal': return <CheckCircle className="w-6 h-6 text-green-600" />;
      case 'Abnormal': return <AlertCircle className="w-6 h-6 text-yellow-600" />;
      case 'Critical': return <AlertCircle className="w-6 h-6 text-red-600" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-red-400 transition">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />

        {preview ? (
          <div className="space-y-4">
            <img
              src={preview}
              alt="ECG Preview"
              className="max-h-64 mx-auto rounded-lg shadow-lg"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="text-sm text-red-500 hover:text-red-600 font-medium"
            >
              Change Image
            </button>
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="cursor-pointer py-12"
          >
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 font-medium">Upload ECG Image</p>
            <p className="text-sm text-gray-500 mt-2">
              Click to browse or drag and drop
            </p>
          </div>
        )}
      </div>

      {selectedFile && !result && (
        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="w-full bg-gradient-to-r from-red-500 to-pink-500 text-white py-4 rounded-xl font-medium hover:from-red-600 hover:to-pink-600 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Analyzing ECG...
            </>
          ) : (
            <>
              <Activity className="w-5 h-5" />
              Analyze ECG
            </>
          )}
        </button>
      )}

      {result && (
        <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-800">Analysis Results</h3>
            {getResultIcon(result.classification_result)}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Classification</p>
              <p className={`text-xl font-bold ${getResultColor(result.classification_result)}`}>
                {result.classification_result}
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Confidence</p>
              <p className="text-xl font-bold text-gray-800">
                {(result.confidence_score * 100).toFixed(1)}%
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Heart Rate</p>
              <p className="text-xl font-bold text-gray-800">
                {result.heart_rate} BPM
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Conditions Found</p>
              <p className="text-xl font-bold text-gray-800">
                {result.detected_conditions.length}
              </p>
            </div>
          </div>

          {result.detected_conditions.length > 0 && (
            <div>
              <p className="text-sm font-medium text-gray-700 mb-3">Detected Conditions:</p>
              <div className="flex flex-wrap gap-2">
                {result.detected_conditions.map((condition: string, index: number) => (
                  <span
                    key={index}
                    className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium"
                  >
                    {condition}
                  </span>
                ))}
              </div>
            </div>
          )}

          <button
            onClick={() => {
              setSelectedFile(null);
              setPreview(null);
              setResult(null);
            }}
            className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition"
          >
            Analyze Another ECG
          </button>
        </div>
      )}
    </div>
  );
};
