import { useEffect, useState } from 'react';
import { Activity, Volume2, AlertTriangle, TrendingUp, Calendar, Heart } from 'lucide-react';
import { supabase, type ECGAnalysis, type VoiceAnalysis, type RiskAssessment } from '../lib/supabase';

interface DashboardProps {
  patientId: string;
}

export const Dashboard = ({ patientId }: DashboardProps) => {
  const [ecgAnalyses, setEcgAnalyses] = useState<ECGAnalysis[]>([]);
  const [voiceAnalyses, setVoiceAnalyses] = useState<VoiceAnalysis[]>([]);
  const [riskAssessments, setRiskAssessments] = useState<RiskAssessment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, [patientId]);

  const loadDashboardData = async () => {
    try {
      const [ecgData, voiceData, riskData] = await Promise.all([
        supabase
          .from('ecg_analyses')
          .select('*')
          .eq('patient_id', patientId)
          .order('analysis_timestamp', { ascending: false })
          .limit(5),
        supabase
          .from('voice_analyses')
          .select('*')
          .eq('patient_id', patientId)
          .order('analysis_timestamp', { ascending: false })
          .limit(5),
        supabase
          .from('risk_assessments')
          .select('*')
          .eq('patient_id', patientId)
          .order('created_at', { ascending: false })
          .limit(5)
      ]);

      if (ecgData.data) setEcgAnalyses(ecgData.data);
      if (voiceData.data) setVoiceAnalyses(voiceData.data);
      if (riskData.data) setRiskAssessments(riskData.data);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const latestRisk = riskAssessments[0];
  const latestECG = ecgAnalyses[0];
  const latestVoice = voiceAnalyses[0];

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-green-100 text-green-700 border-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'High': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Critical': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {latestRisk && (
        <div className={`rounded-xl p-6 border-2 ${getRiskColor(latestRisk.risk_level)}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Heart className="w-8 h-8" />
              <div>
                <h2 className="text-2xl font-bold">Overall Risk Assessment</h2>
                <p className="text-sm opacity-80">Latest evaluation - {new Date(latestRisk.created_at).toLocaleDateString()}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold">{latestRisk.overall_risk_score.toFixed(0)}</div>
              <div className="text-sm font-medium">{latestRisk.risk_level} Risk</div>
            </div>
          </div>

          {latestRisk.recommendations && latestRisk.recommendations.length > 0 && (
            <div className="mt-4 pt-4 border-t border-current opacity-80">
              <p className="font-bold text-lg mb-3 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Your Personalized Action Plan
              </p>
              <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                {latestRisk.recommendations.map((rec: string, index: number) => (
                  <div key={index} className="flex items-start gap-2 text-sm bg-white/10 rounded-lg p-2">
                    <span className="flex-shrink-0">•</span>
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs mt-3 opacity-70">
                💡 Tip: Click on "Risk Assessment" tab to see full details and generate new assessments
              </p>
            </div>
          )}
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-red-100 p-3 rounded-lg">
              <Activity className="w-6 h-6 text-red-500" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">ECG Analyses</h3>
              <p className="text-sm text-gray-600">Total: {ecgAnalyses.length}</p>
            </div>
          </div>
          {latestECG && (
            <div className="space-y-2 pt-4 border-t border-gray-200">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Latest Result:</span>
                <span className="font-medium text-gray-800">{latestECG.classification_result}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Heart Rate:</span>
                <span className="font-medium text-gray-800">{latestECG.heart_rate} BPM</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Confidence:</span>
                <span className="font-medium text-gray-800">
                  {(latestECG.confidence_score * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-teal-100 p-3 rounded-lg">
              <Volume2 className="w-6 h-6 text-teal-500" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Voice Analyses</h3>
              <p className="text-sm text-gray-600">Total: {voiceAnalyses.length}</p>
            </div>
          </div>
          {latestVoice && (
            <div className="space-y-2 pt-4 border-t border-gray-200">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Breathing:</span>
                <span className="font-medium text-gray-800">{latestVoice.breathing_pattern}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Stress Level:</span>
                <span className="font-medium text-gray-800">
                  {(latestVoice.stress_level * 100).toFixed(0)}%
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Fatigue:</span>
                <span className="font-medium text-gray-800">
                  {(latestVoice.vocal_fatigue_score * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Risk Assessments</h3>
              <p className="text-sm text-gray-600">Total: {riskAssessments.length}</p>
            </div>
          </div>
          {riskAssessments.length > 0 && (
            <div className="space-y-2 pt-4 border-t border-gray-200">
              {riskAssessments.slice(0, 3).map((assessment) => (
                <div key={assessment.id} className="flex justify-between items-center text-sm">
                  <span className="text-gray-600 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {new Date(assessment.created_at).toLocaleDateString()}
                  </span>
                  <span className={`font-medium px-2 py-1 rounded text-xs ${getRiskColor(assessment.risk_level)}`}>
                    {assessment.risk_level}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-red-500" />
            Recent ECG Analyses
          </h3>
          {ecgAnalyses.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No ECG analyses yet</p>
          ) : (
            <div className="space-y-3">
              {ecgAnalyses.map((analysis) => (
                <div key={analysis.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-medium text-gray-800">{analysis.classification_result}</span>
                    <span className="text-xs text-gray-500">
                      {new Date(analysis.analysis_timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1">
                    <div>Heart Rate: {analysis.heart_rate} BPM</div>
                    {analysis.detected_conditions && analysis.detected_conditions.length > 0 && (
                      <div className="text-xs text-red-600">
                        {analysis.detected_conditions.length} condition(s) detected
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-teal-500" />
            Recent Voice Analyses
          </h3>
          {voiceAnalyses.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No voice analyses yet</p>
          ) : (
            <div className="space-y-3">
              {voiceAnalyses.map((analysis) => (
                <div key={analysis.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-medium text-gray-800">{analysis.breathing_pattern}</span>
                    <span className="text-xs text-gray-500">
                      {new Date(analysis.analysis_timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1">
                    <div>Stress: {(analysis.stress_level * 100).toFixed(0)}%</div>
                    {analysis.risk_indicators && analysis.risk_indicators.length > 0 && (
                      <div className="text-xs text-yellow-600">
                        {analysis.risk_indicators.length} risk indicator(s)
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
