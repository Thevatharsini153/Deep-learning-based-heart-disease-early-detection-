import { useState, useRef } from 'react';
import { Mic, Square, Loader2, Volume2, AlertCircle } from 'lucide-react';
import { analyzeVoiceBiomarkers } from '../lib/mlModels';
import { supabase } from '../lib/supabase';

interface VoiceAnalysisProps {
  patientId: string;
  onAnalysisComplete: () => void;
}

export const VoiceAnalysis = ({ patientId, onAnalysisComplete }: VoiceAnalysisProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setResult(null);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Unable to access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleAnalyze = async () => {
    if (!audioBlob) return;

    setAnalyzing(true);
    try {
      const analysisResult = await analyzeVoiceBiomarkers(audioBlob);

      const audioUrl = URL.createObjectURL(audioBlob);

      const { error } = await supabase.from('voice_analyses').insert({
        patient_id: patientId,
        audio_url: audioUrl,
        breathing_pattern: analysisResult.breathing_pattern,
        vocal_fatigue_score: analysisResult.vocal_fatigue_score,
        stress_level: analysisResult.stress_level,
        voice_quality_metrics: analysisResult.voice_quality_metrics,
        risk_indicators: analysisResult.risk_indicators,
      });

      if (error) throw error;

      setResult(analysisResult);
      onAnalysisComplete();
    } catch (error: any) {
      console.error('Analysis failed:', error);
      alert('Analysis failed: ' + error.message);
    } finally {
      setAnalyzing(false);
    }
  };

  const getBreathingColor = (pattern: string) => {
    switch (pattern) {
      case 'Normal': return 'text-green-600';
      case 'Irregular': return 'text-yellow-600';
      case 'Labored': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getScoreColor = (score: number) => {
    if (score < 0.3) return 'text-green-600';
    if (score < 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-teal-50 to-blue-50 rounded-xl p-8 text-center">
        {!isRecording && !audioBlob && (
          <div className="space-y-6">
            <div className="bg-white rounded-full p-6 w-24 h-24 mx-auto flex items-center justify-center shadow-lg">
              <Mic className="w-12 h-12 text-teal-500" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Voice Recording</h3>
              <p className="text-gray-600 mb-6">
                Record a 10-second voice sample for biomarker analysis
              </p>
              <button
                onClick={startRecording}
                className="bg-gradient-to-r from-teal-500 to-blue-500 text-white px-8 py-4 rounded-xl font-medium hover:from-teal-600 hover:to-blue-600 transition flex items-center gap-3 mx-auto"
              >
                <Mic className="w-5 h-5" />
                Start Recording
              </button>
            </div>
          </div>
        )}

        {isRecording && (
          <div className="space-y-6">
            <div className="bg-red-500 rounded-full p-6 w-24 h-24 mx-auto flex items-center justify-center shadow-lg animate-pulse">
              <Mic className="w-12 h-12 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Recording...</h3>
              <p className="text-gray-600 mb-6">
                Speak naturally. Say a few sentences about how you're feeling today.
              </p>
              <button
                onClick={stopRecording}
                className="bg-red-500 text-white px-8 py-4 rounded-xl font-medium hover:bg-red-600 transition flex items-center gap-3 mx-auto"
              >
                <Square className="w-5 h-5" />
                Stop Recording
              </button>
            </div>
          </div>
        )}

        {audioBlob && !result && (
          <div className="space-y-6">
            <div className="bg-white rounded-full p-6 w-24 h-24 mx-auto flex items-center justify-center shadow-lg">
              <Volume2 className="w-12 h-12 text-teal-500" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Recording Complete</h3>
              <p className="text-gray-600 mb-6">
                Ready to analyze your voice biomarkers
              </p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={() => {
                    setAudioBlob(null);
                    audioChunksRef.current = [];
                  }}
                  className="bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-medium hover:bg-gray-300 transition"
                >
                  Discard
                </button>
                <button
                  onClick={handleAnalyze}
                  disabled={analyzing}
                  className="bg-gradient-to-r from-teal-500 to-blue-500 text-white px-8 py-3 rounded-lg font-medium hover:from-teal-600 hover:to-blue-600 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {analyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    'Analyze Voice'
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {result && (
        <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-800">Voice Analysis Results</h3>
            <Volume2 className="w-6 h-6 text-teal-500" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Breathing Pattern</p>
              <p className={`text-xl font-bold ${getBreathingColor(result.breathing_pattern)}`}>
                {result.breathing_pattern}
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Vocal Fatigue</p>
              <p className={`text-xl font-bold ${getScoreColor(result.vocal_fatigue_score)}`}>
                {(result.vocal_fatigue_score * 100).toFixed(0)}%
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Stress Level</p>
              <p className={`text-xl font-bold ${getScoreColor(result.stress_level)}`}>
                {(result.stress_level * 100).toFixed(0)}%
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Risk Indicators</p>
              <p className="text-xl font-bold text-gray-800">
                {result.risk_indicators.length}
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 space-y-3">
            <p className="text-sm font-medium text-gray-700">Voice Quality Metrics:</p>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-600">Pitch Variability:</span>
                <span className="ml-2 font-medium text-gray-800">
                  {result.voice_quality_metrics.pitch_variability.toFixed(3)}
                </span>
              </div>
              <div>
                <span className="text-gray-600">Jitter:</span>
                <span className="ml-2 font-medium text-gray-800">
                  {result.voice_quality_metrics.jitter.toFixed(3)}
                </span>
              </div>
              <div>
                <span className="text-gray-600">Shimmer:</span>
                <span className="ml-2 font-medium text-gray-800">
                  {result.voice_quality_metrics.shimmer.toFixed(3)}
                </span>
              </div>
              <div>
                <span className="text-gray-600">Harmonics Ratio:</span>
                <span className="ml-2 font-medium text-gray-800">
                  {result.voice_quality_metrics.harmonics_ratio.toFixed(3)}
                </span>
              </div>
            </div>
          </div>

          {result.risk_indicators.length > 0 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-yellow-800 mb-2">Risk Indicators:</p>
                  <ul className="space-y-1">
                    {result.risk_indicators.map((indicator: string, index: number) => (
                      <li key={index} className="text-sm text-yellow-700">
                        • {indicator}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={() => {
              setAudioBlob(null);
              setResult(null);
              audioChunksRef.current = [];
            }}
            className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 transition"
          >
            Record Another Sample
          </button>
        </div>
      )}
    </div>
  );
};
