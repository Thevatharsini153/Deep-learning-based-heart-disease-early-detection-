import { useState } from 'react';
import { AlertTriangle, CheckCircle, Heart } from 'lucide-react';
import { calculateRiskAssessment } from '../lib/mlModels';
import { supabase, type ECGAnalysis, type VoiceAnalysis } from '../lib/supabase';

interface CombinedAnalysisProps {
  patientId: string;
  latestECG: ECGAnalysis | null;
  latestVoice: VoiceAnalysis | null;
  onComplete: () => void;
}

export const CombinedAnalysis = ({ patientId, latestECG, latestVoice, onComplete }: CombinedAnalysisProps) => {
  const [generating, setGenerating] = useState(false);
  const [assessment, setAssessment] = useState<any>(null);

  const canGenerate = latestECG && latestVoice;

  const handleGenerate = async () => {
    if (!latestECG || !latestVoice) return;

    setGenerating(true);
    try {
      const result = calculateRiskAssessment(
        {
          classification_result: latestECG.classification_result,
          confidence_score: latestECG.confidence_score,
          detected_conditions: Array.isArray(latestECG.detected_conditions)
            ? latestECG.detected_conditions
            : []
        },
        {
          breathing_pattern: latestVoice.breathing_pattern,
          vocal_fatigue_score: latestVoice.vocal_fatigue_score,
          stress_level: latestVoice.stress_level,
          risk_indicators: Array.isArray(latestVoice.risk_indicators)
            ? latestVoice.risk_indicators
            : []
        }
      );

      const { error } = await supabase.from('risk_assessments').insert({
        patient_id: patientId,
        ecg_analysis_id: latestECG.id,
        voice_analysis_id: latestVoice.id,
        overall_risk_score: result.overall_risk_score,
        risk_level: result.risk_level,
        recommendations: result.recommendations,
      });

      if (error) throw error;

      setAssessment(result);
      onComplete();

      setTimeout(() => {
        alert('Risk assessment generated successfully! Check the Dashboard for complete details.');
      }, 500);
    } catch (error: any) {
      console.error('Failed to generate assessment:', error);
      alert('Failed to generate risk assessment: ' + error.message);
    } finally {
      setGenerating(false);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'from-green-500 to-emerald-500';
      case 'Medium': return 'from-yellow-500 to-orange-500';
      case 'High': return 'from-orange-500 to-red-500';
      case 'Critical': return 'from-red-500 to-pink-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getRiskIcon = (level: string) => {
    if (level === 'Low') return <CheckCircle className="w-8 h-8" />;
    return <AlertTriangle className="w-8 h-8" />;
  };

  if (!canGenerate) {
    return (
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 text-center">
        <Heart className="w-12 h-12 text-blue-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-blue-900 mb-2">
          Complete Both Analyses
        </h3>
        <p className="text-blue-700">
          Upload an ECG image and record a voice sample to generate your comprehensive risk assessment.
        </p>
      </div>
    );
  }

  if (assessment) {
    return (
      <div className="space-y-6">
        <div className={`bg-gradient-to-r ${getRiskColor(assessment.risk_level)} text-white rounded-xl p-8`}>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              {getRiskIcon(assessment.risk_level)}
              <div>
                <h2 className="text-3xl font-bold">Risk Assessment Complete</h2>
                <p className="text-white/90">Comprehensive analysis results</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-5xl font-bold">{assessment.overall_risk_score.toFixed(0)}</div>
              <div className="text-lg font-medium">{assessment.risk_level} Risk</div>
            </div>
          </div>

          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-6">
            <h3 className="font-bold text-xl mb-4">📋 Personalized Medical Recommendations</h3>
            <p className="text-white/90 text-sm mb-4">
              Based on your analysis, here are actionable steps to improve your heart health:
            </p>
            <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
              {assessment.recommendations.map((rec: string, index: number) => (
                <div key={index} className="flex items-start gap-3 bg-white/10 rounded-lg p-3">
                  <span className="bg-white/30 rounded-full p-1 flex-shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4" />
                  </span>
                  <span className="text-white/95 text-sm leading-relaxed">{rec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              ECG Analysis Summary
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Result:</span>
                <span className="font-medium text-gray-800">{latestECG.classification_result}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Heart Rate:</span>
                <span className="font-medium text-gray-800">{latestECG.heart_rate} BPM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Conditions:</span>
                <span className="font-medium text-gray-800">
                  {Array.isArray(latestECG.detected_conditions) ? latestECG.detected_conditions.length : 0}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              Voice Analysis Summary
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Breathing:</span>
                <span className="font-medium text-gray-800">{latestVoice.breathing_pattern}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Stress Level:</span>
                <span className="font-medium text-gray-800">
                  {(latestVoice.stress_level * 100).toFixed(0)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Risk Indicators:</span>
                <span className="font-medium text-gray-800">
                  {Array.isArray(latestVoice.risk_indicators) ? latestVoice.risk_indicators.length : 0}
                </span>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={() => setAssessment(null)}
          className="w-full bg-gradient-to-r from-blue-500 to-teal-500 text-white py-4 rounded-xl font-medium hover:from-blue-600 hover:to-teal-600 transition"
        >
          Generate New Assessment
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-xl p-8 text-center">
      <Heart className="w-16 h-16 text-red-500 mx-auto mb-6" />
      <h3 className="text-2xl font-bold text-gray-800 mb-3">
        Ready for Combined Analysis
      </h3>
      <p className="text-gray-600 mb-8">
        Generate a comprehensive risk assessment based on your ECG and voice analyses.
      </p>

      <button
        onClick={handleGenerate}
        disabled={generating}
        className="bg-gradient-to-r from-red-500 to-pink-500 text-white px-8 py-4 rounded-xl font-medium hover:from-red-600 hover:to-pink-600 transition disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center gap-3"
      >
        {generating ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            Generating Assessment...
          </>
        ) : (
          <>
            <Heart className="w-5 h-5" />
            Generate Risk Assessment
          </>
        )}
      </button>
    </div>
  );
};
