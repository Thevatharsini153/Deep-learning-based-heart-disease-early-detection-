/*
  # Heart Disease Early Detection System Schema

  ## Overview
  This migration creates the database schema for a comprehensive heart disease early detection system
  that uses ECG image classification and voice-based biomarkers analysis.

  ## New Tables
  
  ### 1. `patients`
  Stores patient demographic and medical information
    - `id` (uuid, primary key) - Unique patient identifier
    - `user_id` (uuid, foreign key) - Links to auth.users
    - `full_name` (text) - Patient's full name
    - `age` (integer) - Patient age
    - `gender` (text) - Patient gender
    - `medical_history` (jsonb) - Medical history details
    - `created_at` (timestamptz) - Record creation timestamp
    - `updated_at` (timestamptz) - Record update timestamp

  ### 2. `ecg_analyses`
  Stores ECG image analysis results
    - `id` (uuid, primary key) - Unique analysis identifier
    - `patient_id` (uuid, foreign key) - Links to patients
    - `image_url` (text) - URL to ECG image
    - `classification_result` (text) - Classification outcome (Normal, Abnormal, Critical)
    - `confidence_score` (decimal) - Model confidence (0-1)
    - `detected_conditions` (jsonb) - Array of detected conditions
    - `heart_rate` (integer) - Detected heart rate
    - `analysis_timestamp` (timestamptz) - When analysis was performed
    - `created_at` (timestamptz) - Record creation timestamp

  ### 3. `voice_analyses`
  Stores voice biomarker analysis results
    - `id` (uuid, primary key) - Unique analysis identifier
    - `patient_id` (uuid, foreign key) - Links to patients
    - `audio_url` (text) - URL to voice recording
    - `breathing_pattern` (text) - Breathing pattern classification
    - `vocal_fatigue_score` (decimal) - Vocal fatigue indicator (0-1)
    - `stress_level` (decimal) - Stress level indicator (0-1)
    - `voice_quality_metrics` (jsonb) - Detailed voice metrics
    - `risk_indicators` (jsonb) - Identified risk factors
    - `analysis_timestamp` (timestamptz) - When analysis was performed
    - `created_at` (timestamptz) - Record creation timestamp

  ### 4. `risk_assessments`
  Stores combined risk assessment results
    - `id` (uuid, primary key) - Unique assessment identifier
    - `patient_id` (uuid, foreign key) - Links to patients
    - `ecg_analysis_id` (uuid, foreign key) - Links to ecg_analyses
    - `voice_analysis_id` (uuid, foreign key) - Links to voice_analyses
    - `overall_risk_score` (decimal) - Combined risk score (0-100)
    - `risk_level` (text) - Risk classification (Low, Medium, High, Critical)
    - `recommendations` (jsonb) - Personalized recommendations
    - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  
  1. Enable Row Level Security (RLS) on all tables
  2. Policies for patients table:
     - Authenticated users can view their own patient records
     - Authenticated users can create their own patient records
     - Authenticated users can update their own patient records
  3. Policies for ecg_analyses table:
     - Authenticated users can view their own ECG analyses
     - Authenticated users can create their own ECG analyses
  4. Policies for voice_analyses table:
     - Authenticated users can view their own voice analyses
     - Authenticated users can create their own voice analyses
  5. Policies for risk_assessments table:
     - Authenticated users can view their own risk assessments
     - Authenticated users can create their own risk assessments

  ## Notes
  - All timestamps use timestamptz for proper timezone handling
  - JSONB columns allow flexible storage of complex medical data
  - Foreign key constraints ensure data integrity
  - Indexes are added for frequently queried columns to optimize performance
*/

-- Create patients table
CREATE TABLE IF NOT EXISTS patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  full_name text NOT NULL,
  age integer NOT NULL CHECK (age > 0 AND age < 150),
  gender text NOT NULL CHECK (gender IN ('Male', 'Female', 'Other')),
  medical_history jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create ecg_analyses table
CREATE TABLE IF NOT EXISTS ecg_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  image_url text NOT NULL,
  classification_result text NOT NULL CHECK (classification_result IN ('Normal', 'Abnormal', 'Critical')),
  confidence_score decimal NOT NULL CHECK (confidence_score >= 0 AND confidence_score <= 1),
  detected_conditions jsonb DEFAULT '[]'::jsonb,
  heart_rate integer CHECK (heart_rate > 0 AND heart_rate < 300),
  analysis_timestamp timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create voice_analyses table
CREATE TABLE IF NOT EXISTS voice_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  audio_url text NOT NULL,
  breathing_pattern text NOT NULL CHECK (breathing_pattern IN ('Normal', 'Irregular', 'Labored')),
  vocal_fatigue_score decimal NOT NULL CHECK (vocal_fatigue_score >= 0 AND vocal_fatigue_score <= 1),
  stress_level decimal NOT NULL CHECK (stress_level >= 0 AND stress_level <= 1),
  voice_quality_metrics jsonb DEFAULT '{}'::jsonb,
  risk_indicators jsonb DEFAULT '[]'::jsonb,
  analysis_timestamp timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create risk_assessments table
CREATE TABLE IF NOT EXISTS risk_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  ecg_analysis_id uuid REFERENCES ecg_analyses(id) ON DELETE CASCADE,
  voice_analysis_id uuid REFERENCES voice_analyses(id) ON DELETE CASCADE,
  overall_risk_score decimal NOT NULL CHECK (overall_risk_score >= 0 AND overall_risk_score <= 100),
  risk_level text NOT NULL CHECK (risk_level IN ('Low', 'Medium', 'High', 'Critical')),
  recommendations jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_patients_user_id ON patients(user_id);
CREATE INDEX IF NOT EXISTS idx_ecg_analyses_patient_id ON ecg_analyses(patient_id);
CREATE INDEX IF NOT EXISTS idx_voice_analyses_patient_id ON voice_analyses(patient_id);
CREATE INDEX IF NOT EXISTS idx_risk_assessments_patient_id ON risk_assessments(patient_id);
CREATE INDEX IF NOT EXISTS idx_ecg_analyses_timestamp ON ecg_analyses(analysis_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_voice_analyses_timestamp ON voice_analyses(analysis_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_risk_assessments_timestamp ON risk_assessments(created_at DESC);

-- Enable Row Level Security
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE ecg_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE voice_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_assessments ENABLE ROW LEVEL SECURITY;

-- Policies for patients table
CREATE POLICY "Users can view own patient records"
  ON patients FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own patient records"
  ON patients FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own patient records"
  ON patients FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for ecg_analyses table
CREATE POLICY "Users can view own ECG analyses"
  ON ecg_analyses FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM patients
      WHERE patients.id = ecg_analyses.patient_id
      AND patients.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own ECG analyses"
  ON ecg_analyses FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM patients
      WHERE patients.id = patient_id
      AND patients.user_id = auth.uid()
    )
  );

-- Policies for voice_analyses table
CREATE POLICY "Users can view own voice analyses"
  ON voice_analyses FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM patients
      WHERE patients.id = voice_analyses.patient_id
      AND patients.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own voice analyses"
  ON voice_analyses FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM patients
      WHERE patients.id = patient_id
      AND patients.user_id = auth.uid()
    )
  );

-- Policies for risk_assessments table
CREATE POLICY "Users can view own risk assessments"
  ON risk_assessments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM patients
      WHERE patients.id = risk_assessments.patient_id
      AND patients.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own risk assessments"
  ON risk_assessments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM patients
      WHERE patients.id = patient_id
      AND patients.user_id = auth.uid()
    )
  );